; ============================================================
;  NSR-Esign - Inno Setup script
;
;  This turns the portable .exe (already built by build_portable.bat
;  into dist\NSR-Esign.exe) into a proper Windows installer:
;  a Start Menu entry, an optional desktop shortcut, and a listing in
;  "Add or remove programs" with a working uninstaller.
;
;  You normally do NOT run this file directly - build_portable.bat
;  runs it for you automatically (it will offer to install Inno Setup
;  itself first if it isn't already on this computer). It's documented
;  here only for reference, or if you'd rather compile it by hand:
;  open this file in the Inno Setup Compiler and click Build > Compile.
;
;  Requires dist\NSR-Esign.exe to already exist - run
;  build_portable.bat's PyInstaller step first (it always runs before
;  this one).
; ============================================================

#define MyAppName "NSR-Esign"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "Sujith Mayakrishnan"
#define MyAppExeName "NSR-Esign.exe"

[Setup]
; A fixed AppId (any GUID) lets future versions upgrade in place
; instead of installing side-by-side - do not change this once issued.
AppId={{4E9B7C0A-2F3D-4B6E-9A61-6C7B7B3E2F41}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={localappdata}\Programs\{#MyAppName}
DefaultGroupName={#MyAppName}
DisableProgramGroupPage=yes
; Installs for the current user only, under their own profile - this
; needs no administrator rights, which matters on institutional
; computers where staff often don't have admin access. An admin who
; prefers a shared, all-users install can still right-click the
; installer and "Run as administrator"; Inno Setup will then offer
; Program Files instead automatically.
PrivilegesRequired=lowest
PrivilegesRequiredOverridesAllowed=dialog
ArchitecturesInstallIn64BitMode=x64compatible
OutputDir=Output
OutputBaseFilename=NSR-Esign Setup
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
UninstallDisplayIcon={app}\{#MyAppExeName}
DisableWelcomePage=no

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Additional shortcuts:"; Flags: unchecked

[Files]
Source: "dist\{#MyAppExeName}"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{group}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"
Name: "{group}\Uninstall {#MyAppName}"; Filename: "{uninstallexe}"
Name: "{autodesktop}\{#MyAppName}"; Filename: "{app}\{#MyAppExeName}"; Tasks: desktopicon

[Run]
Filename: "{app}\{#MyAppExeName}"; Description: "Launch {#MyAppName} now"; Flags: nowait postinstall skipifsilent
